import java.util.ArrayList;

public class Deck {
    
    public static void buildDeck(){
        ArrayList<Carte> deck ;

        deck = new ArrayList<Carte>();
        
        String[] valeurs = { "A", "2", "3","4","5","6","7","8","9","10","J","Q","K"};
        String[] types = {"T","CA","CO","P","T","CA","CO","P","T","CA","CO","P","T","CA","CO","P" };

        for (int i = 0; i < types.length; i++) {
            for(int j = 0; j< valeurs.length; j++) {
                Carte carte = new Carte(valeurs[j], types[i]);
                deck.add(carte);
            }
        }

        System.out.println("Préparation du deck :");
        System.out.println(deck);

    }
    
}
